<?php
    session_start();
    if(isset($_POST['btn_login']))
    {
        $uname = $_POST['txt_uname'];
        $passwd = $_POST['pwd_login'];
        
        $con= oci_pconnect('pen', 'ink','//localhost/XE');
        if(!$con)
        {
            $m = oci_error();
            echo 'Not connected ',$m['message'];
        }
        else
        {
        $qr= oci_parse($con, "select passwd from LOGIN_USER where uname= :uname");
        oci_bind_by_name($qr, ":uname", $uname);
        oci_execute($qr);
        $res=oci_fetch_array($qr);
            if($res!=FALSE)
            {
                $pwd = $res[0];
                if($pwd)
                {
                    if($pwd==$passwd){
                        $qr1= oci_parse($con,"select aud_users(:un) from dual");
                        oci_bind_by_name($qr1, ":un", $uname); 
                        oci_execute($qr1);
                        $_SESSION['uname']=$uname;
                        echo '<script> window.location.href="../Home_page.html" </script>';
                        
                    }
                    else{
                        echo '<script> alert("You have entered the wrong password! Please enter the correct password ") </script>';
                        echo '<script> window.location.href="../Welcome_page.html" </script>';
                    }
                }
                else {
                    echo '<script> alert("Please check the username !") </script>';
                    echo '<script> window.location.href="../Welcome_page.html" </script>';
                }
            }
            else
            {
                echo '<script> alert("There is no user like you mentioned ") </script> ';
                echo '<script> window.location.href="../Welcome_page.html" </script>';
            }
        oci_close($con);
        }     
    }
    