<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <link rel="stylesheet" href="Common/common.css" type="text/css">
        <link rel="stylesheet" href="CSS/Profile.css" type="text/css">
        <link rel="stylesheet" href="CSS/Home_page.css" type="text/css">
        <link rel="icon" href="Images/app_icon.png" type="image/x-icon" />

        <script type="text/javascript" src="Js/jquery_file.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous" ></script>
        <script type="text/javascript" src="Js/functions.js" ></script>
        
    </head>
    <body>
        <?php
        session_start();
        $con = oci_pconnect('pen', 'ink', '//localhost/XE');
        $usrname = $_SESSION['uname'];
        $qr2 = oci_parse($con, "select u_address from tbl_user where u_id=:uname");
        oci_bind_by_name($qr2, ":uname", $usrname);
        oci_execute($qr2);
        $res = oci_fetch_array($qr2);
        $usraddr = $res[0];
        $_SESSION['usraddr'] = $usraddr;
        ?>       
        <div> Welcome <?php echo $usrname; ?> , Please verify your details.
        </div>
        <div>
            <input type="file" accept="image/*" id="usr_pic" name="usr_pic" onchange="readURL(this);" hidden="" >
            <img id="temp_img" class="pro_pic" height="50%" width="20%" />
        </div>

    </body>
</html>
