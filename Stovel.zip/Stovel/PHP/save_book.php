<?php
// Uploads files
session_start();
if (isset($_POST['btn_submit'])) { // if save button on the form is clicked
    $f_name = basename($_FILES['file_bk']['name']);
    // destination of the file on the server
    $path='Books/';
    $destination = $path . $f_name;
    // get the file extension
    $extension = strtolower(pathinfo($f_name, PATHINFO_EXTENSION));
    // the physical file on a temporary uploads directory on the server
    $f_tmp_name = $_FILES['file_bk']['tmp_name'];
    $f_size = $_FILES['file_bk']['size'];
    $file_array = array('pdf', 'docx');
    if (!in_array($extension, $file_array)) {
        echo "Your file extension must be .zip, .pdf or .docx";
    } elseif ($_FILES['file_bk']['size'] > 10000000) { // file shouldn't be larger than 10MB
        echo "File too large!";
    } else {
        
        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($f_tmp_name, $destination)) { 
            
            $con= oci_pconnect('pen', 'ink','//localhost/XE');
            $qr= oci_parse($con,"begin prc_save_book(:b_name,:b_auth,:b_rel_yr,:error); end;");
            oci_bind_by_name($qr, ":b_name", $f_name);
            oci_bind_by_name($qr, ":b_auth", $b_auth);
            oci_bind_by_name($qr, ":b_rel_yr", $b_rel_yr);
            oci_bind_by_name($qr, ":error", $db_error);
            oci_execute($qr);
            
            if($db_error == 2){
                echo "<script> alert('File uploaded in Server but not in DB!'); </script>";
                echo "<script> location.href='../Home_page.html' </script>";               
            }
            elseif($db_error == 1) { 
                echo "<script> alert('Already the file exists!');</script> <br/> ";
                echo "<script> location.href='../Home_page.html' </script>";
            }
            else
            {
                echo "<script> alert('File uploaded successfully.');</script> <br/> ";
                echo "<script> location.href='../Home_page.html' </script>";
            }
        } 
        else {
            echo "<script> alert('Failed to upload file.');</script>";
            echo "<script> location.href='../Home_page.html' </script>";
        }
    }
}
