<?php 
session_start(); 
if(isset($_POST['btn_signin_1']))
{
    $usr_name = $_POST['txt_user_name'];
    $usr_dob= date_format(date_create($_POST['dt_dob']), 'd-M-y');
    $usr_addr=$_POST['user_address'];
    $u_name=$_POST['txt_u_name'];
    $u_passwd = $_POST['pwd_usr_passwd'];
    $prc_error="";
    $con= oci_pconnect('pen', 'ink','//localhost/XE');
        if(!$con)
        {
            $m = oci_error();
            echo 'Not connected ',$m['message'];
        }
        else
        {
        $qr= oci_parse($con,"begin proc_create_user(:a,:b,:c,:d,:e,:f); end;");
        oci_bind_by_name($qr, ":a", $u_name);
        oci_bind_by_name($qr, ":b", $u_passwd);
        oci_bind_by_name($qr, ":c", $usr_name);
        oci_bind_by_name($qr, ":d", $usr_dob);
        oci_bind_by_name($qr, ":e", $usr_addr);
        oci_bind_by_name($qr, ":f", $prc_error);
            if(oci_execute($qr))
            {
                echo '<script> alert("Successfully signed up. Please login now!");'.
                 'window.location.href="../Welcome_page.html" </script>';
            }
        }
    
}
 else {
     echo '<script> alert("Unable to receive the data ! Please check your details");';
     echo '<script> window.location.href="Welcome_page.html" </script>';
}
