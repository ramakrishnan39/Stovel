function enable_signin()
{
    document.getElementById("signup_part").style.visibility = "visible";
    document.getElementById("signup_btn").style.visibility = "hidden";
}
function call_welcome_screen()
{
    location.href = "Welcome_page.html";
}
function call_home()
{
    location.href = "Home_page.html";
}

function show_file(in_elem, op_elem)
{
    var fname = document.getElementById(in_elem).files[0].name;
    document.getElementById(op_elem).innerHTML = fname;
}
function show_edit()
{
    var ch_cnt = document.getElementById("profile_name").childElementCount;
    if (ch_cnt === 0)
    {
        var pel = document.getElementById("profile_name");
        var node = document.createElement("p");
        node.setAttribute("id", "profile_tag");
        node.appendChild(document.createTextNode("Your profile is here "));
        pel.parentNode.replaceChild(node, pel);
    }
}

function show_person()
{
    var div1 = document.getElementById("person_details");
    var newdiv1 = document.createElement("div");
    newdiv1.innerHTML = 'Welcome to the page profile';
    div1.parentNode.replaceChild(newdiv1, div1);
}
function readURL(input) 
{
    var fr= new FileReader();
    fr.onload = function(e)
    { $("#temp_img").attr('src',e.target.result);
    };
    fr.readAsDataURL(input.files[0]);
}